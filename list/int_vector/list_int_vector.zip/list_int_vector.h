

//ElemType ElemCopy(const ElemType *e)
//{
//    return *e;
//    //ElemType new_elem;
//    //new_elem.data = malloc(sizeof(int)*e->size);
//    //new_elem.size = e->size;
//    //memcpy(new_elem.data, e->data, sizeof(int)*e->size);
//    //return new_elem;
//}
//
//void ElemDelete(ElemType *e)
//{
//    //free(e->data);
//}